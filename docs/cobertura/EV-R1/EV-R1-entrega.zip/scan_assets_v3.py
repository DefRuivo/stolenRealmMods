import sys,json,collections,hashlib,uuid,copy
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'dependencias'))
import UnityPy
from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator
ROOT=Path('E:/SteamLibrary/steamapps/common/Stolen Realm/Stolen Realm_Data')
OUT=BASE/'evidencias/assets'
gen=TypeTreeGenerator('2022.3.62f1');gen.load_local_dll_folder(str(ROOT/'Managed'))
v2=json.loads((OUT/'resources.assets-v2.json').read_text(encoding='utf-8'))
env=UnityPy.load(str(ROOT/'resources.assets'));env.typetree_generator=gen
sf=env.file; nodes={};fixes=collections.Counter();records=[];errors=[]
TARGETS={'PartyEvent','ListHolderEvents','EventStatus','QuestInfo','BattleInfo','LootTable','SkillInfo','CharacterAttribute','StatusInfo'}
def repair(n):
    if n.m_Type=='string' and n.m_Children and n.m_Children[0].m_Type=='Array' and n.m_Children[0].m_Children[-1].m_Type=='string':
        n.m_Type='vector';fixes['string_collection']+=1
    for c in n.m_Children:repair(c)
for header in v2['headers']:
    sn=header['script']
    if sn not in TARGETS:continue
    o=sf.objects[header['path_id']]
    try:
        h=o.parse_monobehaviour_head();sc=h.m_Script.read()
        if sn not in nodes:
            n=gen.get_nodes_up(sc.m_AssemblyName,(sc.m_Namespace+'.' if sc.m_Namespace else '')+sn)
            # Use shipped native header nodes, not generator header offsets.
            native=o._get_typetree_node()
            n.m_Children[:4]=native.m_Children[:4]
            repair(n);nodes[sn]=n
        d=o.read_typetree(nodes=nodes[sn])
        assert d['m_Script']=={'m_FileID':h.m_Script.m_FileID,'m_PathID':h.m_Script.m_PathID}
        assert d['m_Name']==h.m_Name
        records.append({'file':sf.name,'path_id':o.path_id,'script':sn,'data':d,'raw_sha256':hashlib.sha256(o.get_raw_data()).hexdigest()})
    except Exception as e:errors.append({'file':sf.name,'id':o.path_id,'script':sn,'error':str(e)})
for sn,n in nodes.items():
    with (OUT/(sn+'-typetree-v3.txt')).open('x',encoding='utf-8') as f:f.write(n.dump_structure())
r={'source':str(ROOT/'resources.assets'),'records':records,'errors':errors,'fixes':dict(fixes),'header_count':len(v2['headers'])}
with (OUT/'resources-extraidos-v3.json').open('x',encoding='utf-8') as f:json.dump(r,f,ensure_ascii=False,indent=2)
print('RECORDS',collections.Counter(r['script'] for r in records));print('FIXES',fixes);print('ERRORS',len(errors),errors[:15]);
pe=next(r for r in records if r['script']=='PartyEvent');print('SAMPLE',json.dumps(pe,ensure_ascii=False)[:16000])
