import unittest,json,copy,re,hashlib,uuid,collections
from pathlib import Path
from leitor_offline import BASE,ROOT,Reader,ppointers,odin_guid
import jsonschema
D=BASE/'docs/cobertura/EV-R1'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def walk_nulls(v,path='$'):
    if v is None:yield path
    elif isinstance(v,dict):
        for k,x in v.items():yield from walk_nulls(x,path+'.'+k)
    elif isinstance(v,list):
        for i,x in enumerate(v):yield from walk_nulls(x,f'{path}[{i}]')
def gate_coverage(data,declared):
    keys=[e['origem']['path_id'] for e in data['eventos']]
    if len(keys)!=len(set(keys)) or set(keys)!=declared:raise ValueError('cobertura de objetos divergente')
class TestEVR1(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=load(D/'eventos.json');cls.events=cls.data['eventos'];cls.schema=load(D/'eventos.schema.json')
        cls.cat=load(D/'catalogo-referencias.json');cls.orig=load(D/'eventos-originais.json')
        cls.v2=load(BASE/'evidencias/assets/resources.assets-v2.json');cls.globaldata=load(BASE/'evidencias/assets/globalgamemanagers-v1.json')
        cls.ordered={r['path_id']:r for r in cls.orig};cls.reader=Reader()
        cls.declared={h['path_id'] for h in cls.v2['headers'] if h['script']=='PartyEvent'}
    def test_01_schema_payload(self):
        jsonschema.Draft202012Validator.check_schema(self.schema)
        jsonschema.Draft202012Validator(self.schema,format_checker=jsonschema.FormatChecker()).validate(self.data)
    def test_02_256_headers_vs_holder_vs_output(self):
        holder=next(r for r in self.cat['registros'] if r['script']=='ListHolderEvents')
        declared={p['m_PathID'] for p in holder['data']['Events']}
        self.assertEqual(len(self.declared),256);self.assertEqual(declared,self.declared)
        gate_coverage(self.data,declared);self.assertEqual(len(self.events),256)
    def test_03_fresh_offline_read_all_256(self):
        for e in self.events:
            r=self.reader.read(e['origem']['path_id'])
            self.assertEqual(r['data'],e['campos_originais'],e['chave'])
            self.assertEqual(r['raw_sha256'],e['origem']['sha256_objeto'])
    def test_04_roundtrip_all_256_bytes(self):
        from UnityPy.helpers import TypeTreeHelper
        from UnityPy.streams import EndianBinaryWriter
        for e in self.events:
            pid=e['origem']['path_id'];o=self.reader.file.objects[pid];n,h,s=self.reader.node(o)
            w=EndianBinaryWriter(endian=o.reader.endian);TypeTreeHelper.write_typetree(e['campos_originais'],n,w,o.assets_file)
            self.assertEqual(w.bytes,o.get_raw_data(),e['chave'])
    def test_05_roundtrip_all_177_statuses(self):
        from UnityPy.helpers import TypeTreeHelper
        from UnityPy.streams import EndianBinaryWriter
        statuses=[r for r in self.cat['registros'] if r['script']=='EventStatus'];self.assertEqual(len(statuses),177)
        for r in statuses:
            pid=r['path_id'];fresh=self.reader.read(pid);self.assertEqual(fresh['data'],r['data'])
            o=self.reader.file.objects[pid];n,h,s=self.reader.node(o);w=EndianBinaryWriter(endian=o.reader.endian)
            TypeTreeHelper.write_typetree(r['data'],n,w,o.assets_file);self.assertEqual(w.bytes,o.get_raw_data(),str(pid))
    def test_06_source_strings_not_rewritten(self):
        for e in self.events:
            raw=self.ordered[e['origem']['path_id']]['data']
            self.assertEqual(e['texto'],raw['encounterText']);self.assertEqual(e['texto_resultados_possiveis'],raw['encounterPossibleResultsText'])
            title=raw['EventNameOverride'] if raw['EventNameOverride'].strip() else raw['m_Name'];self.assertEqual(e['titulo'],title)
            for o,ro in zip(e['opcoes'],raw['eventOptions'],strict=True):
                self.assertEqual(o['titulo'],ro['title']);self.assertEqual(o['texto'],ro['description'])
                for a,ra in zip(o['efeitos'],ro['eventActions'],strict=True):self.assertEqual(a['texto'],ra['activationText'])
    def test_07_option_action_totals(self):
        options=sum(len(e['opcoes']) for e in self.events);actions=sum(len(o['efeitos']) for e in self.events for o in e['opcoes'])
        self.assertEqual(options,404);self.assertEqual(actions,449)
        self.assertEqual(options,self.data['cobertura']['opcoes']);self.assertEqual(actions,self.data['cobertura']['acoes'])
    def test_08_all_effects_and_overrides_preserved(self):
        for e in self.events:
            for o in e['opcoes']:
                for a in o['efeitos']:
                    self.assertEqual([x['campos_originais'] for x in a['efeitos']],a['campos_originais']['EventActionEffects'])
                    self.assertEqual(len(a['overrides']),len(a['campos_originais']['EventActionEffectOverrides']))
                    for ov,raw in zip(a['overrides'],a['campos_originais']['EventActionEffectOverrides'],strict=True):
                        self.assertEqual(ov['modo']['valor'],raw['FullReleaseMode'])
                        self.assertEqual([x['campos_originais'] for x in ov['efeitos']],raw['EventActionEffects'])
    def test_09_all_reward_flags_and_parameters_exact(self):
        for e in self.events:
            for o in e['opcoes']:
                for a in o['efeitos']:
                    for ef in a['efeitos']+[x for ov in a['overrides'] for x in ov['efeitos']]:
                        raw=ef['campos_originais'];rr=ef['recompensas']
                        self.assertEqual(rr['ouro']['dar'],bool(raw['giveGold']));self.assertEqual(rr['ouro']['retirar'],bool(raw['takeGold']))
                        self.assertEqual(rr['ouro']['razao'],raw['goldAmountRatio']);self.assertEqual(rr['experiencia']['razao'],raw['expAmountRatio'])
                        self.assertEqual(rr['itens']['tabelas'],raw['lootTables']);self.assertEqual(rr['itens']['restricoes'],raw['lootRestrictions'])
                        self.assertEqual(rr['itens']['quantidade_configurada'],raw['itemCount']);self.assertIsNone(rr['itens']['sorteio_final'])
    def test_10_nulls_have_reasons(self):
        for e in self.events:
            self.assertEqual(set(walk_nulls(e)),set(e['ausencias']))
            self.assertTrue(all(e['ausencias'].values()))
    def test_11_guids_preserved_duplicate_not_dropped(self):
        groups=collections.defaultdict(list)
        for e in self.events:
            self.assertEqual(e['id'],odin_guid(e['campos_originais'])[0]);uuid.UUID(e['id']);groups[e['id']].append(e['chave'])
        self.assertEqual(len(groups),255)
        self.assertEqual({k:v for k,v in groups.items() if len(v)>1},self.data['cobertura']['guid_duplicados'])
    def test_12_category_pool_and_disability(self):
        counts=collections.Counter(e['categoria'] for e in self.events)
        self.assertEqual(dict(counts),self.data['cobertura']['categorias'])
        self.assertEqual(dict(counts),{'AfterBattle':1,'Normal':160,'NotInEventPool':84,'QuestStart':1,'SemPoolDeclarado':10})
        self.assertEqual(sum(bool(e['condicoes']['disabled']) for e in self.events),42)
        for e in self.events:self.assertEqual([p['valor'] for p in e['pool']],e['campos_originais']['EventSpawnTypes'])
    def test_13_reconcile_resource_paths(self):
        c=self.globaldata['resources'][0]['data']['m_Container']
        paths=collections.defaultdict(list)
        for name,p in c:
            if p['m_FileID']==4:paths[p['m_PathID']].append(name)
        for e in self.events:
            self.assertEqual(e['origem']['caminhos_resource'],paths[e['origem']['path_id']]);self.assertTrue(all(x.startswith('events/') for x in e['origem']['caminhos_resource']))
    def test_14_all_direct_gameplay_pptrs_resolve(self):
        failures={r['path_id'] for r in self.cat['falhas_auxiliares']};records={r['path_id'] for r in self.cat['registros']}
        for e in self.events:
            for path,p in ppointers(e['campos_originais']):
                if p['m_FileID']!=0:continue
                self.assertIn(p['m_PathID'],self.reader.file.objects,(e['chave'],path))
                o=self.reader.file.objects[p['m_PathID']]
                if o.type.name=='MonoBehaviour':self.assertIn(p['m_PathID'],records,(e['chave'],path));self.assertNotIn(p['m_PathID'],failures)
    def test_15_index_and_human_markdown_all_events(self):
        index=(D/'indice.md').read_text(encoding='utf-8');human=(D/'revisao-por-evento.md').read_text(encoding='utf-8')
        self.assertEqual(index.count(' — `resources.assets:'),256);self.assertEqual(human.count('Chave: `resources.assets:'),256)
        for e in self.events:
            self.assertIn(e['chave'],index);self.assertIn(e['chave'],human)
            if e['texto']:self.assertIn(e['texto'],human)
    def test_16_category_lots_all_events_once(self):
        keys=[]
        for category,n in self.data['cobertura']['categorias'].items():
            s=(D/f'lote-{category}.md').read_text(encoding='utf-8')
            extracted=re.findall(r'Chave: `(resources\.assets:[0-9]+)`',s);self.assertEqual(len(extracted),n);keys.extend(extracted)
        self.assertEqual(len(keys),len(set(keys)));self.assertEqual(set(keys),{e['chave'] for e in self.events})
    def test_17_exclusions_honest(self):
        failures=self.cat['falhas_auxiliares'];self.assertEqual(len(failures),3);self.assertEqual({x['script'] for x in failures},{'ActionInfoTest'})
        self.assertTrue(self.data['cobertura']['nao_exercitado'])
    def test_18_negative_missing_event_trips_coverage(self):
        bad=copy.deepcopy(self.data);bad['eventos'].pop()
        with self.assertRaises(ValueError):gate_coverage(bad,self.declared)
    def test_19_negative_invented_final_reward_trips_schema(self):
        bad=copy.deepcopy(self.data);ef=next(ef for e in bad['eventos'] for o in e['opcoes'] for a in o['efeitos'] for ef in a['efeitos'])
        ef['recompensas']['ouro']['quantidade_final']=123
        with self.assertRaises(jsonschema.ValidationError):jsonschema.validate(bad,self.schema)
    def test_20_negative_absent_required_field_trips_schema(self):
        bad=copy.deepcopy(self.data);del bad['eventos'][0]['origem']
        with self.assertRaises(jsonschema.ValidationError):jsonschema.validate(bad,self.schema)
    def test_21_source_assembly_unchanged(self):
        self.assertEqual(hashlib.sha256((ROOT/'Managed/Assembly-CSharp.dll').read_bytes()).hexdigest(),'8bb4a7c512da20770a81dfac0347e9a68a8c0eff736f4566c52a66923b37855a')
    def test_22_all_enums_resolved(self):
        def walk(v):
            if isinstance(v,dict):
                if set(v).issuperset({'valor','nome'}):self.assertIsNotNone(v['nome'],v)
                for x in v.values():walk(x)
            elif isinstance(v,list):
                for x in v:walk(x)
        for e in self.events:walk(e)
if __name__=='__main__':unittest.main(verbosity=2)
