"""Build immutable EV-R1 human/AI deliverables from verified offline catalog."""
import sys,json,re,uuid,hashlib,collections,ast
from pathlib import Path
from leitor_offline import BASE,ROOT,odin_guid,ppointers
OUT=BASE/'docs/cobertura/EV-R1';OUT.mkdir(parents=True,exist_ok=True)
CAT=json.loads((BASE/'evidencias/assets/catalogo-v9.json').read_text(encoding='utf-8'))
RECS={f'{r["file"]}:{r["path_id"]}':r for r in CAT['records']}
CODEPATH=BASE/'evidencias/codigo/Assembly-CSharp.decompiled.cs'
CODE=CODEPATH.read_text(encoding='utf-8')
def put(name,obj):
    with (OUT/name).open('x',encoding='utf-8') as f:
        if isinstance(obj,str):f.write(obj)
        else:json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while b:=f.read(8*1024*1024):h.update(b)
    return h.hexdigest()
def enum_map(name):
    m=re.search(r'\benum '+re.escape(name)+r'\s*\{([^}]+)\}',CODE)
    if not m:return {}
    text=re.sub(r'//[^\n]*','',m.group(1));res={};n=0
    for part in text.split(','):
        part=part.strip()
        if not part:continue
        bits=part.split('=');key=bits[0].strip()
        if len(bits)>1:
            try:n=int(bits[1].strip(),0)
            except ValueError:continue
        res[n]=key;n+=1
    return res
ENUMS={n:enum_map(n) for n in ['EventSpawnType','ItemQuality','GameMode','StorySetting','FullReleaseMode','NodeType','TerrainType','TimeOfDay','RollBonusType','EventResultType','EventCharacterPoolType','EventTargetType','UniversalLootTableType','PersistentDurationType','StatusType','CharacterEffectMethod','EventActionEffectTargetType']}
def en(name,v):
    label=ENUMS[name].get(v)
    d={'valor':v,'nome':label}
    if label is None:d['motivo']='Valor sem nome resolvido no enum '+name+' do assembly instalado.'
    return d
def ref(p):
    if not p.get('m_PathID'):return {'chave':None,'nome':None,'motivo':'PPtr serializado com m_PathID=0 (referência nula no asset).'}
    k=f'resources.assets:{p["m_PathID"]}' if p['m_FileID']==0 else f'external:{p["m_FileID"]}:{p["m_PathID"]}'
    rr=RECS.get(k);rs=CAT['reference_summaries'].get(k,{})
    name=rr['data'].get('Name') or rr['data'].get('m_Name') if rr else rs.get('name')
    d={'chave':k,'nome':name,'pptr':p}
    if name is None:d['motivo']='Nome não disponível no resumo offline; PPtr original preservado.'
    if rr:d['tipo']=rr['script']
    elif rs.get('script') or rs.get('type'):d['tipo']=rs.get('script') or rs.get('type')
    if rr and rr['script']=='EventStatus':
        data=rr['data'];d['descricao']=data['statusDescription'];d['duracao']=en('PersistentDurationType',data['durationType']);d['status_tipo']=en('StatusType',data['StatusType'])
        d['modificadores']=[{'atributo':ref(e['characterAttribute']),'metodo':en('CharacterEffectMethod',e['method']),'expressao':e['amount'],'segunda_passagem':bool(e['calculateOnSecondPass'])} for e in data['eventStatusEffects']]
    return d
def rewards(e):
    return {'ouro':{'dar':bool(e['giveGold']),'retirar':bool(e['takeGold']),'razao':e['goldAmountRatio'],'quantidade_final':None,'motivo':'Calculada em EventOption.InitActions: GetQuestGold(nível), razão e GoldMultiplier; requer estado da partida.'},'experiencia':{'dar':bool(e['giveExperience']),'razao':e['expAmountRatio'],'quantidade_final':None,'motivo':'Calculada em EventOption.InitActions; pode ser convertida em ouro no roguelike/party nível 30; requer estado da partida.'},'itens':{'dar':bool(e['giveItems']),'pool_tipo':en('UniversalLootTableType',e['itemPoolType']),'quantidade_configurada':e['itemCount'],'tabelas':e['lootTables'],'restricoes':e['lootRestrictions'],'sorteio_final':None,'motivo':'EventOption.InitActions/LootTable.GetLoot dependem de nível, restrições e RNG; tabelas autorais preservadas.'},'status':{'candidatos':[ref(p) for p in e['eventStatuses']],'sortear':bool(e['pickRandomStatus']),'quantidade_sorteada_configurada':e['randomStatusCount'],'resultado_sorteado':None,'motivo':'Configuração de candidatos preservada; resultado da partida não exercitado.'},'skills':[ref(p) for p in e['eventSkills']]}
def effects(e):
    return {'vida_mana':{k:e[k] for k in ['percentMaxHealth','percentMaxMana','percentCurHealth','percentCurMana']},'alvo':{'override':bool(e['OverrideTargetType']),'tipo_override':en('EventActionEffectTargetType',e['TargetTypeOverride']),'tipo_default_serializado':en('EventActionEffectTargetType',e['DefaultEventActionEffectTargetType'])},'recompensas':rewards(e),'remocoes_status':e['statusRemovals'],'campos_originais':e}
def nulls(v,p='$'):
    if v is None:yield p
    elif isinstance(v,dict):
        for k,x in v.items():yield from nulls(x,p+'.'+k)
    elif isinstance(v,list):
        for i,x in enumerate(v):yield from nulls(x,f'{p}[{i}]')
def build_event(r):
    d=r['data'];gid,why=odin_guid(d);pools=[en('EventSpawnType',v) for v in d['EventSpawnTypes']]
    category='+'.join(x['nome'] or str(x['valor']) for x in pools) or 'SemPoolDeclarado'
    opts=[]
    for i,o in enumerate(d['eventOptions'],1):
        actions=[]
        for j,a in enumerate(o['eventActions'],1):
            actions.append({'indice':j,'texto':a['activationText'],'resultado':en('EventResultType',a['eventResultSetting']['EventResultType']),'limite_rolagem':a['eventResultSetting']['RollLimit'],'texto_efeitos_manual':a['manualEffectText'],'efeitos':[effects(e) for e in a['EventActionEffects']],'overrides':[{'modo':en('FullReleaseMode',ov['FullReleaseMode']),'efeitos':[effects(e) for e in ov['EventActionEffects']]} for ov in a['EventActionEffectOverrides']],'batalha':{'iniciar':bool(a['startBattle']),'manual':bool(a['manuallySetBattle']),'referencia':ref(a['battle']),'override':a['battleOverrideInfo'],'dados_recompensa_final':None,'motivo':'Configuração de combate preservada; inimigos, loot/XP efetivos e modificadores são resolvidos no runtime, não exercitado.'},'evento_encadeado':ref(a['chainedEvent']),'campos_originais':a})
        opts.append({'indice':i,'titulo':o['title'],'texto':o['description'],'condicoes':{'status_requeridos':[ref(p) for p in o['requiredStatuses']],'ocultar_sem_requisitos':bool(o['hideIfRequiredStatusesNotMet']),'ocultar_se_status':[ref(p) for p in o['hideIfHasStatuses']]},'rolagem':{'bonus':[en('RollBonusType',v) for v in o['rollBonusTypes']],'misteriosa':bool(o['mysteryRollValue']),'texto_misterioso':o['mysteryRollEffectText']},'efeitos':actions,'recompensas':[{'acao':a['indice'],'padrao':[e['recompensas'] for e in a['efeitos']],'overrides':[{'modo':ov['modo'],'recompensas':[e['recompensas'] for e in ov['efeitos']]} for ov in a['overrides']]} for a in actions],'campos_originais':o})
    key=f'{r["file"]}:{r["path_id"]}'
    event={'chave':key,'id':gid,'categoria':category,'titulo':d['EventNameOverride'] if d['EventNameOverride'].strip() else d['m_Name'],'nome_asset':d['m_Name'],'texto':d['encounterText'],'texto_resultados_possiveis':d['encounterPossibleResultsText'],'opcoes':opts,'raridade':en('ItemQuality',d['rarity']),'peso':d['ChanceRatio'],'pool':pools,'condicoes':{k:d[k] for k in ['disabled','EditorOnly','allowOnAllNodeTypes','allowedNodeTypes','requiredStatusesToSpawn','allowOnAllTerrainTypes','allowedTerrainTypes','allowAtAllTimesOfDay','allowedTimeOfDay','allowAtAllLevels','minLevel','terrainTypesAllowedAtAnyTime','KeepInDeckWhenUsed','isLesserEvent','LeadsToFortune']},'modos':[en('GameMode',v) for v in d['GameModes']],'historia':en('StorySetting',d['StorySetting']),'full_release':en('FullReleaseMode',d['FullReleaseMode']),'origem':{'arquivo':r['file'],'path_id':r['path_id'],'caminhos_resource':CAT['resource_paths'].get(key,[]),'sha256_objeto':r['raw_sha256'],'tipo':'PartyEvent','codigo':'Assembly-CSharp.decompiled.cs: PartyEvent, EventOption, EventAction, EventActionEffects'},'campos_originais':d,'ausencias':{}}
    for path in nulls(event):
        event['ausencias'][path]=why if path=='$.id' else 'NULL declarado: referência nula, resultado dependente de runtime ou valor nulo do leitor; veja motivo no objeto contêiner e campos_originais.'
    return event
EVENTS=sorted([build_event(r) for r in CAT['records'] if r['script']=='PartyEvent'],key=lambda e:(e['categoria'],e['titulo'].casefold(),e['chave']))
holder=next(r for r in CAT['records'] if r['script']=='ListHolderEvents')
headers=json.loads((BASE/'evidencias/assets/resources.assets-v2.json').read_text(encoding='utf-8'))['headers']
counts=collections.Counter(e['categoria'] for e in EVENTS);guid=collections.defaultdict(list)
for e in EVENTS:guid[e['id']].append(e['chave'])
coverage={'eventos_extraidos':len(EVENTS),'party_event_cabecalhos':sum(h['script']=='PartyEvent' for h in headers),'list_holder_declarados':len(holder['data']['Events']),'list_holder_unicos':len({p['m_PathID'] for p in holder['data']['Events']}),'roundtrip_bytes_identicos':sum(x['same_bytes'] for x in CAT['roundtrips']),'guid_unicos':len(guid),'guid_duplicados':{k:v for k,v in guid.items() if len(v)>1},'categorias':dict(counts),'opcoes':sum(len(e['opcoes']) for e in EVENTS),'acoes':sum(len(o['efeitos']) for e in EVENTS for o in e['opcoes']),'assets_desabilitados':sum(bool(e['condicoes']['disabled']) for e in EVENTS),'referencias_registros_decodificados':len(CAT['records']),'referencias_resumos':len(CAT['reference_summaries']),'falhas_auxiliares':CAT['errors'],'nao_exercitado':['execução no jogo/runtime','traduções/localização selecionada','quantidades finais de ouro/XP/loot','sorteios e disponibilidade na partida','decodificação integral de três ActionInfoTest auxiliares']}
manifest={'assembly':{'caminho':str(ROOT/'Managed/Assembly-CSharp.dll'),'sha256':sha(ROOT/'Managed/Assembly-CSharp.dll')},'decompilado':{'caminho':'evidencias/codigo/Assembly-CSharp.decompiled.cs','sha256':sha(CODEPATH),'linhas':len(CODE.splitlines()),'ferramenta':'ilspycmd 8.2.0.7535'},'build_info_literal':(ROOT/'StreamingAssets/build_info').read_text(),'assets':[]}
for p in ROOT.iterdir():
    if p.is_file() and (p.suffix=='.assets' or p.name=='globalgamemanagers' or p.name in ('level0','level1','level2')):manifest['assets'].append({'arquivo':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
put('eventos.json',{'schema_version':'1.0.0','fontes':manifest,'cobertura':coverage,'eventos':EVENTS})
put('cobertura.json',coverage);put('fontes.json',manifest);put('enums.json',ENUMS)
put('catalogo-referencias.json',{'schema_version':'1.0.0','registros':CAT['records'],'resumos':CAT['reference_summaries'],'falhas_auxiliares':CAT['errors']})
put('eventos-originais.json',[r for r in CAT['records'] if r['script']=='PartyEvent'])
put('prova-roundtrip.json',CAT['roundtrips'])
# Render source strings verbatim. JSON fences preserve all condition/reward fields.
def js(v):return json.dumps(v,ensure_ascii=False,indent=2)
def text(s):return s if s else '(string vazia no asset)'
def render(e):
    lines=[f'## {e["titulo"]}',f'Chave: `{e["chave"]}` — GUID: `{e["id"]}`',f'Categoria: {e["categoria"]} — raridade: {e["raridade"]["nome"]} ({e["raridade"]["valor"]}) — peso relativo: {e["peso"]}',f'Origem: {", ".join(e["origem"]["caminhos_resource"])} — SHA objeto: `{e["origem"]["sha256_objeto"]}`','', '### Texto original',text(e['texto']),'','### Resultados possíveis (texto autoral)',text(e['texto_resultados_possiveis']),'','### Condições e modos','```json',js({'condicoes':e['condicoes'],'modos':e['modos'],'historia':e['historia'],'full_release':e['full_release']}),'```','']
    for o in e['opcoes']:
        lines += [f'### Opção {o["indice"]}: {o["titulo"]}',text(o['texto']),'','Condições/rolagem:','```json',js({'condicoes':o['condicoes'],'rolagem':o['rolagem']}),'```','']
        for a in o['efeitos']:
            lines += [f'#### Ação {a["indice"]}: {a["resultado"]["nome"]} — RollLimit {a["limite_rolagem"]}',text(a['texto']),'']
            for i,ef in enumerate(a['efeitos'],1):
                slim={k:v for k,v in ef.items() if k!='campos_originais'}
                lines += [f'Efeito {i} (configuração autoral, não resultado de partida):','```json',js(slim),'```','']
            if a['texto_efeitos_manual']:lines+=['Texto manual de efeitos:','```json',js(a['texto_efeitos_manual']),'```']
            if a['overrides']:
                slim=[{'modo':x['modo'],'efeitos':[{k:v for k,v in ef.items() if k!='campos_originais'} for ef in x['efeitos']]} for x in a['overrides']]
                lines+=['Overrides por FullReleaseMode (todos preservados):','```json',js(slim),'```']
            if a['batalha']['iniciar']:lines+=['Combate configurado:','```json',js(a['batalha']),'```']
            if a['evento_encadeado']['chave'] is not None:lines+=['Evento encadeado:','```json',js(a['evento_encadeado']),'```']
    return '\n'.join(lines)+'\n'
index=['# EV-R1 — índice de TODOS os PartyEvent instalados','',f'{len(EVENTS)} assets; {len(guid)} GUIDs únicos. Não deduplicar por GUID.','', 'Schema: eventos.schema.json; dados: eventos.json; originais: eventos-originais.json; referências: catalogo-referencias.json.','', 'Todos os textos são originais em inglês, inclusive placeholders. Não são traduções nem melhorias. NULL não é recompensa zero. Eventos desabilitados e fora do pool permanecem.','']
for category,n in counts.items():
    cname=f'lote-{category}.md'; subset=[e for e in EVENTS if e['categoria']==category]
    put(cname,'# EV-R1 — '+category+f' ({n} eventos)\n\n'+'\n---\n\n'.join(render(e) for e in subset))
    index += [f'## {category} ({n})',f'Lote completo: `{cname}`','']
    for e in subset:index.append(f'- {e["titulo"]} — `{e["chave"]}` — `{e["id"]}` — disabled={e["condicoes"]["disabled"]}')
    index.append('')
put('indice.md','\n'.join(index)+'\n')
put('revisao-por-evento.md','# EV-R1 — revisão integral\n\n'+'\n---\n\n'.join(render(e) for e in EVENTS))
print('BUILT',js(coverage));print('OUT',OUT)
