import sys,json,collections,hashlib,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'dependencias'))
import UnityPy
from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator
ROOT=Path('E:/SteamLibrary/steamapps/common/Stolen Realm/Stolen Realm_Data')
OUT=BASE/'evidencias/assets';OUT.mkdir(parents=True,exist_ok=True)
gen=TypeTreeGenerator('2022.3.62f1');gen.load_local_dll_folder(str(ROOT/'Managed'))
TARGETS={'PartyEvent','ListHolderEvents','EventStatus','GlobalSettings','QuestInfo','BattleInfo','LootTable','SkillInfo','CharacterAttribute','ResourceReferenceCollection','WorldMapGeneratorSettings','UniversalLootTables','StatusInfo'}
all_counts={};total_errors=[]
for p in ROOT.iterdir():
    if not p.is_file() or (p.suffix!='.assets' and not (p.name.startswith('level') and '.' not in p.name)):continue
    print('LOAD',p.name,flush=True)
    env=UnityPy.load(str(p));env.typetree_generator=gen
    counts=collections.Counter();cache={};records=[];errors=[];headers=[];containers={}
    for o in env.objects:
        if o.assets_file.name!=p.name:continue
        if o.type.name=='ResourceManager':
            containers[str(o.path_id)]=o.read_typetree()
        if o.type.name!='MonoBehaviour':continue
        try:
            h=o.parse_monobehaviour_head();s=h.m_Script
            key=(s.m_FileID,s.m_PathID)
            if key not in cache:cache[key]=s.read()
            sc=cache[key];sn=sc.m_ClassName;counts[sn]+=1
            headers.append({'file':p.name,'path_id':o.path_id,'script':sn,'name':h.m_Name,'size':o.byte_size})
            if sn in TARGETS:
                full=(sc.m_Namespace+'.' if sc.m_Namespace else '')+sn
                node=gen.get_nodes_up(sc.m_AssemblyName,full)
                d=o.read_typetree(nodes=node)
                records.append({'file':p.name,'path_id':o.path_id,'script':sn,'data':d})
        except Exception as e:errors.append({'file':p.name,'id':o.path_id,'script':locals().get('sn'),'error':str(e)})
    res={'source':str(p),'size':p.stat().st_size,'counts':dict(counts),'headers':headers,'records':records,'errors':errors,'containers':containers,'objects':sum(1 for o in env.objects if o.assets_file.name==p.name)}
    dest=OUT/(p.name+'-v2.json')
    with dest.open('x',encoding='utf-8') as f:json.dump(res,f,ensure_ascii=False,indent=2)
    all_counts[p.name]=dict(counts);total_errors.extend(errors)
    print('RESULT',p.name,'objects',res['objects'],'PartyEvent',counts['PartyEvent'],'records',len(records),'errors',len(errors),flush=True)
    print('SAMPLE',json.dumps(next((r for r in records if r['script']=='PartyEvent'),{}),ensure_ascii=False)[:10000],flush=True)
with (OUT/'inventario-v2.json').open('x',encoding='utf-8') as f:json.dump({'counts':all_counts,'errors':total_errors},f,ensure_ascii=False,indent=2)
