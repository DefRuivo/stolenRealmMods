"""EV-R1 validation v2: compare Markdown after newline normalization.
Canonical JSON preserves the exact authored strings, including CR characters.
read_text applies universal-newline decoding; normalize only the expected Markdown
representation, not JSON or source fields. Original failed run remains archived.
"""
from pathlib import Path
BASE=Path(__file__).resolve().parent
source=(BASE/'test_eventos.py').read_text(encoding='utf-8')
old="if e['texto']:self.assertIn(e['texto'],human)"
new="if e['texto']:self.assertIn(e['texto'].replace('\\r\\n','\\n').replace('\\r','\\n'),human)"
assert source.count(old)==1
source=source.replace(old,new)
exec(compile(source,str(BASE/'test_eventos.py'),'exec'))
