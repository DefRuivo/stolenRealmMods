"""Alternative v7: pure-Python typetree reader, no Boost cache."""
import sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'dependencias'))
from UnityPy.helpers import TypeTreeHelper
TypeTreeHelper.read_typetree_boost=None
source=(BASE/'scan_assets_v6.py').read_text(encoding='utf-8')
source=source.replace('-v6','-v7')
exec(compile(source,str(BASE/'scan_assets_v6.py'),'exec'))
