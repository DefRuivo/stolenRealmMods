"""Offline helpers. Never loads Unity runtime or executes game DLLs."""
import sys,uuid,struct,hashlib
from pathlib import Path
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'dependencias'))
import UnityPy
from UnityPy.helpers import TypeTreeHelper
from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator
from UnityPy.helpers.Tpk import get_typetree_node
from UnityPy.enums import ClassIDType
TypeTreeHelper.read_typetree_boost=None
ROOT=Path('E:/SteamLibrary/steamapps/common/Stolen Realm/Stolen Realm_Data')
def fix_node(n):
    cs=n.m_Children
    if n.m_Type=='string' and cs and cs[0].m_Type=='Array' and cs[0].m_Children[-1].m_Type=='string':n.m_Type='vector'
    n.m_Children=[fix_node(c) for c in cs]
    return n
class Reader:
    def __init__(self):
        self.env=UnityPy.load(str(ROOT/'resources.assets'))
        self.file=self.env.file
        self.gen=TypeTreeGenerator('2022.3.62f1');self.gen.load_local_dll_folder(str(ROOT/'Managed'))
        self.nodes={};self.cache={}
    def node(self,o):
        h=o.parse_monobehaviour_head();s=h.m_Script.read()
        full=(s.m_Namespace+'.' if s.m_Namespace else '')+s.m_ClassName
        key=(s.m_AssemblyName,full)
        if key not in self.nodes:
            n=self.gen.get_nodes_up(*key)
            native=get_typetree_node(ClassIDType.MonoBehaviour,o.version)
            n.m_Children=native.m_Children[:4]+n.m_Children[4:]
            self.nodes[key]=fix_node(n)
        return self.nodes[key],h,s
    def read(self,pid):
        if pid in self.cache:return self.cache[pid]
        o=self.file.objects[pid]
        n,h,s=self.node(o)
        d=o.read_typetree(nodes=n)
        assert d['m_Name']==h.m_Name
        assert d['m_Script']=={'m_FileID':h.m_Script.m_FileID,'m_PathID':h.m_Script.m_PathID}
        r={'file':self.file.name,'path_id':pid,'script':s.m_ClassName,'data':d,'raw_sha256':hashlib.sha256(o.get_raw_data()).hexdigest()}
        self.cache[pid]=r
        return r

def odin_guid(data):
    raw=bytes(data.get('serializationData',{}).get('SerializedBytes',[]))
    # NamedGuid (41), UTF-16 flag (1), int32 name length, name, 16-byte .NET GUID.
    if len(raw)<6 or raw[0]!=41 or raw[1]!=1:return None,'GUID não presente como primeira entrada Odin NamedGuid UTF-16; bytes preservados.'
    count=struct.unpack_from('<I',raw,2)[0]
    end=6+count*2
    if end+16>len(raw):return None,'Entrada Odin NamedGuid incompleta; bytes preservados.'
    name=raw[6:end].decode('utf-16-le')
    if name not in ('Id','Guid'):return None,'Primeira entrada Odin não é Id/Guid; bytes preservados.'
    return str(uuid.UUID(bytes_le=raw[end:end+16])),None

def ppointers(v,path='$'):
    if isinstance(v,dict):
        if set(v)=={'m_FileID','m_PathID'}:
            if v['m_PathID']:yield path,v
        else:
            for k,x in v.items():yield from ppointers(x,path+'.'+k)
    elif isinstance(v,list):
        for i,x in enumerate(v):yield from ppointers(x,f'{path}[{i}]')
