import json,hashlib,zipfile
from pathlib import Path
from leitor_offline import BASE
import jsonschema
files={}
def add(p,name=None):
    name=name or p.relative_to(BASE).as_posix()
    assert p.is_file(),str(p);assert name not in files,name
    files[name]=p
for p in (BASE/'docs').rglob('*'):
    if p.is_file():add(p)
for p in BASE.glob('*.py'):add(p)
add(BASE/'LEIA-ME.md')
for name in ['testes-03.txt','repro-principal.txt','scan-assets-v7.txt','scan-catalogo-v8.txt','scan-catalogo-v9.txt','gerar-entrega.txt','scan-global.txt']:
    add(BASE/name)
add(BASE/'evidencias/codigo/Assembly-CSharp.decompiled.cs')
for name in ['resources.assets-v2.json','resources-extraidos-v7.json','globalgamemanagers-v1.json']:
    add(BASE/'evidencias/assets'/name)
for p in (BASE/'evidencias/assets').glob('*-typetree-v7.txt'):add(p)
for name in ['testes-repro.txt','repro-conferencia.json','scan_headers_offline.py.log']:
    add(BASE/'repro-limpa'/name)
add(BASE/'repro-limpa/evidencias/assets/inventario-limpo.json')
manifest=[{'arquivo':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(files.items())]
M=BASE/'manifesto-entrega.json'
with M.open('x',encoding='utf-8') as f:json.dump({'arquivos':manifest,'quantidade':len(manifest),'tarefa':'t_48d68679'},f,ensure_ascii=False,indent=2)
Z=BASE/'EV-R1-entrega.zip'
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in sorted(files.items()):z.write(p,n)
    z.write(M,M.name)
with zipfile.ZipFile(Z) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(manifest)+1
    for row in manifest:assert hashlib.sha256(z.read(row['arquivo'])).hexdigest()==row['sha256'],row['arquivo']
    data=json.loads(z.read('docs/cobertura/EV-R1/eventos.json'));schema=json.loads(z.read('docs/cobertura/EV-R1/eventos.schema.json'))
    jsonschema.Draft202012Validator(schema,format_checker=jsonschema.FormatChecker()).validate(data)
    assert len(data['eventos'])==256
    repro=json.loads(z.read('repro-limpa/repro-conferencia.json'));assert repro['eventos_identicos_ao_original'] is True
    assert sum('lote-' in n and n.endswith('-v2.md') for n in z.namelist())==5
report={'arquivo':str(Z),'bytes':Z.stat().st_size,'sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),'entradas':len(manifest)+1,'eventos':len(data['eventos']),'zip_crc_ok':True,'sha256_todos_arquivos_ok':True,'schema_no_zip_ok':True,'reproducao_identica':True}
assert report['bytes']<25*1024*1024,'Archive exceeds attachment cap'
with (BASE/'verificacao-pacote.json').open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
print(json.dumps(report,ensure_ascii=False,indent=2))
