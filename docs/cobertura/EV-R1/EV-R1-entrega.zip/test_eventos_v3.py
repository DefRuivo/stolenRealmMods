"""Final tests against immutable Markdown v2 and canonical JSON."""
from pathlib import Path
BASE=Path(__file__).resolve().parent
source=(BASE/'test_eventos.py').read_text(encoding='utf-8')
old="if e['texto']:self.assertIn(e['texto'],human)"
new="if e['texto']:self.assertIn(e['texto'].replace('\\r\\n','\\n').replace('\\r','\\n'),human)"
assert source.count(old)==1
source=source.replace(old,new)
source=source.replace("D/'indice.md'","D/'indice-v2.md'").replace("D/'revisao-por-evento.md'","D/'revisao-por-evento-v2.md'").replace("f'lote-{category}.md'","f'lote-{category}-v2.md'")
exec(compile(source,str(BASE/'test_eventos.py'),'exec'))
