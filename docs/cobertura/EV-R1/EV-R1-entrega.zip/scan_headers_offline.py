"""Clean offline inventory: native headers and repaired full typetrees."""
import json,collections
from leitor_offline import BASE,ROOT,Reader
import UnityPy
OUT=BASE/'evidencias/assets';OUT.mkdir(parents=True,exist_ok=True)
rd=Reader();headers=[];errors=[];counts=collections.Counter();scripts={}
for o in rd.env.objects:
    if o.assets_file.name!='resources.assets' or o.type.name!='MonoBehaviour':continue
    try:
        h=o.parse_monobehaviour_head();key=(h.m_Script.m_FileID,h.m_Script.m_PathID)
        if key not in scripts:scripts[key]=h.m_Script.read().m_ClassName
        sn=scripts[key];counts[sn]+=1
        headers.append({'file':'resources.assets','path_id':o.path_id,'script':sn,'name':h.m_Name,'size':o.byte_size})
    except Exception as e:errors.append({'file':'resources.assets','path_id':o.path_id,'error':str(e)})
with (OUT/'resources.assets-v2.json').open('x',encoding='utf-8') as f:json.dump({'headers':headers,'counts':dict(counts),'errors':errors},f,ensure_ascii=False,indent=2)
seeds={'PartyEvent','EventStatus','QuestInfo','BattleInfo','ListHolderEvents'}
records=[rd.read(h['path_id']) for h in headers if h['script'] in seeds]
with (OUT/'resources-extraidos-v7.json').open('x',encoding='utf-8') as f:json.dump({'records':records,'errors':[]},f,ensure_ascii=False,indent=2)
# Check every other serialized file and scene, including globalgamemanagers.
files=[];extra_party=[];globals_out=None
for p in ROOT.iterdir():
    if not p.is_file() or p.name=='resources.assets':continue
    if not (p.suffix=='.assets' or p.name in ('globalgamemanagers','level0','level1','level2')):continue
    env=UnityPy.load(str(p));cs=collections.Counter();rs=[];hs=[];errs=[]
    for o in env.objects:
        if o.assets_file.name!=p.name:continue
        if o.type.name=='ResourceManager':rs.append({'file':p.name,'path_id':o.path_id,'data':o.read_typetree()})
        if o.type.name=='MonoBehaviour':
            try:
                h=o.parse_monobehaviour_head();sn=h.m_Script.read().m_ClassName;cs[sn]+=1
                if sn=='PartyEvent':extra_party.append({'file':p.name,'path_id':o.path_id,'name':h.m_Name})
            except Exception as e:errs.append({'id':o.path_id,'error':str(e)})
    files.append({'file':p.name,'mono_counts':dict(cs),'errors':errs})
    if p.name=='globalgamemanagers':globals_out={'resources':rs,'headers':hs,'errors':errs}
assert globals_out is not None
with (OUT/'globalgamemanagers-v1.json').open('x',encoding='utf-8') as f:json.dump(globals_out,f,ensure_ascii=False,indent=2)
with (OUT/'inventario-limpo.json').open('x',encoding='utf-8') as f:json.dump({'resources_counts':dict(counts),'resources_errors':errors,'other_files':files,'extra_party_event':extra_party},f,ensure_ascii=False,indent=2)
assert not extra_party,'Additional PartyEvent objects need extraction; refusing incomplete dump.'
assert counts['PartyEvent']==256,'Installed corpus changed; re-review coverage before using this version.'
print('CLEAN INVENTORY',counts['PartyEvent'],'PartyEvent;',len(records),'full seed records;',len(files)+1,'serialized files/scenes;',len(errors),'null-script header errors')
