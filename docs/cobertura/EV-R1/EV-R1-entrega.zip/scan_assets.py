import sys,json,collections,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'dependencias'))
import UnityPy
root=Path('E:/SteamLibrary/steamapps/common/Stolen Realm/Stolen Realm_Data')
out=Path(__file__).resolve().parent/'evidencias/assets'
out.mkdir(parents=True,exist_ok=True)
p=root/'resources.assets'
print('Loading',p,flush=True)
env=UnityPy.load(str(p))
counts=collections.Counter(); samples={}; records=[]; errors=[]
for o in env.objects:
    if o.type.name!='MonoBehaviour':continue
    try:
        d=o.read_typetree()
        s=d.get('m_Script',{})
        so=o.assets_file.objects.get(s.get('m_PathID')) if s.get('m_FileID')==0 else None
        sn=so.read().m_Name if so else 'EXTERNAL'
        counts[sn]+=1
        if sn in ('PartyEvent','ListHolderEvents','EventStatus','GlobalSettings','Quest','QuestInfo'):
            records.append({'file':o.assets_file.name,'path_id':o.path_id,'script':sn,'data':d})
            if sn not in samples:samples[sn]=d
    except Exception as e:errors.append({'id':o.path_id,'error':str(e)})
result={'counts':dict(counts),'samples':samples,'records':records,'errors':errors,'objects':len(list(env.objects))}
pout=out/'resources-inventario.json'
with pout.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print('COUNTS',counts,flush=True);print('ERRORS',len(errors));print('SAMPLE',json.dumps(samples,ensure_ascii=False)[:14000]);print('OUTPUT',pout)
