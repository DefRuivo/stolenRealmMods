"""Reproduce extraction in a NEW folder, never overwrite artifacts.
Usage: python reproduzir_offline.py --out C:/path/new --deps C:/path/dependencias
Without --deps, installs pinned packages into the new folder.
"""
import argparse,subprocess,sys,shutil,json
from pathlib import Path
SRC=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--deps');a=p.parse_args()
DST=Path(a.out).resolve()
if DST.exists():raise SystemExit('Destination must not exist; immutable artifact rule.')
DST.mkdir(parents=True)
scripts=['leitor_offline.py','scan_headers_offline.py','scan_catalogo_v8.py','scan_catalogo_v9.py','gerar_entrega.py','render_human_v2.py','test_eventos.py','test_eventos_v3.py']
for name in scripts:shutil.copyfile(SRC/name,DST/name)
if a.deps:shutil.copytree(Path(a.deps).resolve(),DST/'dependencias')
else:subprocess.run([sys.executable,'-m','pip','install','--target',str(DST/'dependencias'),'UnityPy==1.25.4','TypeTreeGeneratorAPI==0.0.10','jsonschema==4.26.0'],check=True)
(DST/'evidencias/codigo').mkdir(parents=True)
assembly='E:/SteamLibrary/steamapps/common/Stolen Realm/Stolen Realm_Data/Managed/Assembly-CSharp.dll'
with (DST/'repro-decompilacao.txt').open('x',encoding='utf-8') as f:subprocess.run(['ilspycmd','-o',str(DST/'evidencias/codigo'),assembly],stdout=f,stderr=subprocess.STDOUT,check=True)
for name in ['scan_headers_offline.py','scan_catalogo_v9.py','gerar_entrega.py','render_human_v2.py']:
    print('RUN',name,flush=True)
    with (DST/(name+'.log')).open('x',encoding='utf-8') as f:subprocess.run([sys.executable,str(DST/name)],cwd=DST,stdout=f,stderr=subprocess.STDOUT,check=True)
D=DST/'docs/cobertura/EV-R1';shutil.copyfile(SRC/'docs/cobertura/EV-R1/eventos.schema.json',D/'eventos.schema.json')
with (DST/'testes-repro.txt').open('x',encoding='utf-8') as f:subprocess.run([sys.executable,str(DST/'test_eventos_v3.py')],cwd=DST,stdout=f,stderr=subprocess.STDOUT,check=True)
old=json.loads((SRC/'docs/cobertura/EV-R1/eventos.json').read_text(encoding='utf-8')) if (SRC/'docs/cobertura/EV-R1/eventos.json').exists() else None
new=json.loads((D/'eventos.json').read_text(encoding='utf-8'))
comparison={'eventos':len(new['eventos']),'coverage':new['cobertura'],'eventos_identicos_ao_original':new['eventos']==old['eventos'] if old else None,'motivo':None if old else 'Sem dump original no diretório dos scripts; comparação não aplicável.'}
if old:assert comparison['eventos_identicos_ao_original'],'Divergent payload between independent extractions.'
with (DST/'repro-conferencia.json').open('x',encoding='utf-8') as f:json.dump(comparison,f,ensure_ascii=False,indent=2)
print('REPRO VERIFIED',len(new['eventos']),'events; 22 tests passed;',DST,flush=True)
