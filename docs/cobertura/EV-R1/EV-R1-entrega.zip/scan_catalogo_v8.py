import sys,json,collections,hashlib
from pathlib import Path
from leitor_offline import Reader,ROOT,BASE,ppointers,odin_guid
OUT=BASE/'evidencias/assets'
v2=json.loads((OUT/'resources.assets-v2.json').read_text(encoding='utf-8'))
v7=json.loads((OUT/'resources-extraidos-v7.json').read_text(encoding='utf-8'))
rd=Reader(); rd.cache={r['path_id']:r for r in v7['records']}
headers={r['path_id']:r for r in v2['headers']}
q=collections.deque();visited=set();included={};errors=[];refs={};roundtrips=[]
for r in v7['records']:
    if r['script'] in ('PartyEvent','EventStatus','QuestInfo','BattleInfo','ListHolderEvents'):q.append(r['path_id'])
for h in headers.values():
    if h['script'] in ('GlobalSettings','RoguelikeSettings','QuestRewardProfile'):q.append(h['path_id'])
while q:
    pid=q.popleft()
    if pid in visited:continue
    visited.add(pid)
    try:
        r=rd.read(pid);included[pid]=r
        # Global context is preserved but not a seed for unrelated complete game data.
        follow=r['script'] not in ('GlobalSettings','RoguelikeSettings')
        for path,p in ppointers(r['data']):
            f=p['m_FileID'];target=p['m_PathID']
            if f==0:
                o=rd.file.objects.get(target)
                if o is None:refs[f'resources.assets:{target}']={'file':'resources.assets','path_id':target,'error':'PPtr ausente no arquivo'};continue
                key=f'resources.assets:{target}'
                if key not in refs:
                    if o.type.name=='MonoBehaviour':
                        h=headers.get(target)
                        if h:refs[key]={'file':'resources.assets','path_id':target,'type':o.type.name,'script':h['script'],'name':h['name']}
                        else:refs[key]={'file':'resources.assets','path_id':target,'type':o.type.name,'error':'MonoBehaviour sem cabeçalho no censo'}
                    else:
                        try:d=o.read();name=getattr(d,'m_Name',None)
                        except Exception:name=None
                        refs[key]={'file':'resources.assets','path_id':target,'type':o.type.name,'script':None,'name':name}
                if follow and o.type.name=='MonoBehaviour' and target in headers:q.append(target)
            else:
                ex=rd.file.externals[f-1] if f<=len(rd.file.externals) else None
                name=str(getattr(ex,'path',None)) if ex else None
                refs[f'external:{f}:{target}']={'file_id':f,'path_id':target,'external':name,'reason':'Referência externa de script/apresentação; não é definição PartyEvent local.'}
    except Exception as e:errors.append({'path_id':pid,'script':headers.get(pid,{}).get('script'),'error':str(e)})
# Byte-for-byte roundtrip of ALL PartyEvent objects using repaired typetrees.
from UnityPy.helpers import TypeTreeHelper
from UnityPy.streams import EndianBinaryWriter
for r in included.values():
    if r['script']!='PartyEvent':continue
    o=rd.file.objects[r['path_id']];node,h,s=rd.node(o);writer=EndianBinaryWriter(endian=o.reader.endian)
    TypeTreeHelper.write_typetree(r['data'],node,writer,o.assets_file)
    raw=o.get_raw_data();same=writer.bytes==raw
    roundtrips.append({'path_id':r['path_id'],'same_bytes':same,'source_bytes':len(raw),'written_bytes':len(writer.bytes)})
    if not same:errors.append({'path_id':r['path_id'],'error':'roundtrip bytes differ'})
# ResourceManager table: resolve using declared externals, not assumed file index.
globalenv=__import__('UnityPy').load(str(ROOT/'globalgamemanagers'));gf=globalenv.file
ex=[getattr(x,'path',str(x)) for x in gf.externals]
g=json.loads((OUT/'globalgamemanagers-v1.json').read_text(encoding='utf-8'))
paths={};others=[]
for path,p in g['resources'][0]['data']['m_Container']:
    f=p['m_FileID'];filename=Path(ex[f-1]).name if f and f<=len(ex) else gf.name
    key=f'{filename}:{p["m_PathID"]}'
    paths.setdefault(key,[]).append(path)
    if path.startswith('events/') and p['m_PathID'] not in included:others.append({'path':path,'target':key})
result={'records':list(included.values()),'reference_summaries':refs,'resource_paths':paths,'global_externals':ex,'errors':errors,'roundtrips':roundtrips,'counts':dict(collections.Counter(r['script'] for r in included.values())),'event_path_other_objects':others}
with (OUT/'catalogo-v8.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print('COUNTS',result['counts']);print('REFERENCES',len(refs),'ERRORS',len(errors),errors[:12]);print('ROUNDTRIPS',collections.Counter(x['same_bytes'] for x in roundtrips));print('GLOBAL_EXTERNALS',ex);print('EVENT_PATH_OTHER_OBJECTS',len(others));print('GUID_UNIQUE',len({odin_guid(r['data'])[0] for r in included.values() if r['script']=='PartyEvent'}))
