"""Recover managed SerializeReference typetrees from the installed DLL."""
from leitor_offline import Reader,BASE,fix_node
from UnityPy.helpers import TypeTreeHelper
orig=TypeTreeHelper.get_ref_type_node
rd=Reader();cache={}
def managed_node(ref_object,assetfile):
    try:return orig(ref_object,assetfile)
    except ValueError as exc:
        t=ref_object['type'];name=t['class'];ns=t['ns'];asm=t['asm']
        if not name:return None
        key=(asm,(ns+'.' if ns else '')+name)
        if key not in cache:
            n=rd.gen.get_nodes_up(*key)
            # Generator adds MonoBehaviour header even for plain managed classes.
            n.m_Children=n.m_Children[4:]
            cache[key]=fix_node(n)
        return cache[key]
TypeTreeHelper.get_ref_type_node=managed_node
for pid in [2545001,2545043]:
    r=rd.read(pid);print('READ',r['script'],pid,r['data']['m_Name'],r['raw_sha256'])
source=(BASE/'scan_catalogo_v8.py').read_text(encoding='utf-8').replace('catalogo-v8','catalogo-v9')
exec(compile(source,str(BASE/'scan_catalogo_v8.py'),'exec'))
