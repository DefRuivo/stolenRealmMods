"""Immutable Markdown revision: no Windows newline translation on write."""
import ast,json
from pathlib import Path
from leitor_offline import BASE
D=BASE/'docs/cobertura/EV-R1'
data=json.loads((D/'eventos.json').read_text(encoding='utf-8'));events=data['eventos']
module=ast.parse((BASE/'gerar_entrega.py').read_text(encoding='utf-8'))
functions=[n for n in module.body if isinstance(n,ast.FunctionDef) and n.name in ('js','text','render')]
assert len(functions)==3
exec(compile(ast.Module(body=functions,type_ignores=[]),'<source-renderer-functions>','exec'))
def put(name,txt):
    with (D/name).open('x',encoding='utf-8',newline='') as f:f.write(txt)
counts=data['cobertura']['categorias']
index=['# EV-R1 — índice final v2','',f'{len(events)} PartyEvent; 404 opções; 449 ações. Todos os assets, inclusive desabilitados e fora do pool.','', 'Dados canônicos: eventos.json. Schema: eventos.schema.json. Guia: schema.md. Leitura integral: revisao-por-evento-v2.md.','', 'Revisão v2 corrige apenas a tradução automática CR/LF do gravador Markdown no Windows. Os strings de eventos.json e os textos autorais não foram alterados.','']
for category,n in counts.items():
    name=f'lote-{category}-v2.md';es=[e for e in events if e['categoria']==category]
    put(name,f'# EV-R1 — {category} ({n})\n\n'+'\n---\n\n'.join(render(e) for e in es))
    index += [f'## {category} ({n})',f'Lote completo: `{name}`','']
    for e in es:index.append(f'- {e["titulo"]} — `{e["chave"]}` — `{e["id"]}` — disabled={e["condicoes"]["disabled"]}')
    index.append('')
put('indice-v2.md','\n'.join(index)+'\n')
put('revisao-por-evento-v2.md','# EV-R1 — revisão integral final v2\n\n'+'\n---\n\n'.join(render(e) for e in events))
print('RENDERED',len(events),'events into',len(counts),'lots; newline translation disabled')
